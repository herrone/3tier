﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessObjects;

/* Delivery System Coursework 
 * Author - Emily Herron
 * Matric - 40506487
 * Completed on 22/11/21
 */
namespace DataLayer
{
    /*
     * this is a facade to Get through to DB without complications for the user, all methods here just call the db
     */
    public class DataFacadeSingleton
    {
        private static DataFacadeSingleton reference;
        //instantiate self
        private DataFacadeSingleton()
        {
            //empty constructor
        }

        public static DataFacadeSingleton GetInstance()
        { //to make work as singleton
            if (reference == null)
            { // if it hasn't been done before
                reference = new DataFacadeSingleton(); //make a new one
            }
            return reference;
        }

        Logfile lf = new Logfile(); // instantiate the Logfile so it can also be accessed through here
        public void LogItdf(string message)
        {
            lf.PrintToLog(message); // there is a case swtich statement for message in Logfile

        }

        private Database db = new Database(); //instantiate the db so it can be used to persist objects

        //Save Courier to DB
        public void AddCourierdf(Courier m)
        { // this method calls the db version, passing the courier to be added, which was passed to itself
            db.AddCourierDB(m);

        }
        public void AddParceldf(Parcel s)
        { // this method calls the db version, passing the parcel to be added, which was passed to itself
            db.AddParcelDB(s);

        }

        public List<Courier> GetAllCouriersdf()
        {
            // this method calls the db version, and returns the full list of couriers
            return db.ReadCourierCsv();

        }
        public void PrintParcelsdf(List<Parcel> ps)
        { // this method calls the db version, passing the parcels to be Printed, which were passed to itself
            db.CsvPrintparcels(ps);
        }
        public void PrintCouriersdf(List<Courier> cs)
        { // this method calls the db version, passing the couriers to be Printed, which were passed to itself
            db.CsvPrintcouriers(cs);
        }
        public List<Parcel> GetAllParcelsdf()
        {
            // this method calls the db version, and returns the full list of parcels
            return db.ReadParcelCsv();

        }

    }
}