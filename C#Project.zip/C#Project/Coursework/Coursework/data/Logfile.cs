﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* Delivery System Coursework 
 * Author - Emily Herron
 * Matric - 40506487
 * Completed on 22/11/21
 */

namespace DataLayer
{
    class Logfile
    {
        public Logfile()
        {
            //empty constructor
        }

        public void PrintToLog(string code)
        { // this method Prints to the logfile, based on which code it recieves
            string path = "logfile.txt"; // where to Print
            string message = "";
            switch (code) // switch statement 
            {
                case "addcourier":
                    message = (DateTime.Now + " - added new courier");
                    break;

                case "transferparcel":
                    message = (DateTime.Now + " - transferred parcel to new courier");
                    break;

                case "addparcel":
                    message = (DateTime.Now + " - added new parcel");
                    break;
                case "showdeliverylist":
                    message = (DateTime.Now + " - Printed courier's delivery list");
                    break;
                case "getall":
                    message = (DateTime.Now + " - Printed all couriers");
                    break;

                default:
                   
                    break;
            }
            if (message.Length > 1)
            {

                File.AppendAllText(path, message + Environment.NewLine); //Print line to the file specified above 
            }
        }
    }
}