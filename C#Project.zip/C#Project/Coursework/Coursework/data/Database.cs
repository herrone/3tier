﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessObjects;
using System.Xml.Serialization;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

/* Delivery System Coursework 
 * Author - Emily Herron
 * Matric - 40506487
 * Completed on 22/11/21
 */

namespace DataLayer
{ 
    class Database

    {
        public Database()
        {
            //empty constructor
        }

        public void AddCourierDB(Courier a)
        { // this method is called by dbfacase, and adds a courier to the file
            List<Courier> retrieved = new List<Courier>(); // blank list
            if (File.Exists("courier3.csv")) // if the file is already there (ie. a courier exists in system)
            {
                retrieved = this.ReadCourierCsv(); // blank list is set to result of reading in said couriers

            }

            retrieved.Add(a); // add this new courier to the list

            if (File.Exists("courier3.csv"))
            {
                File.Delete("courier3.csv"); //delete the original file

            }

            this.CsvPrintcouriers(retrieved); // print list with new courier in it 

        }

        public void AddParcelDB(Parcel a)
        { // this is the exact same as the method above, but for parcels

            List<Parcel> retrieved = new List<Parcel>();
            if (File.Exists("justparcels.csv"))
            {
                retrieved = this.ReadParcelCsv();

            }

            retrieved.Add(a);

            if (File.Exists("justparcels.csv"))
            {
                File.Delete("justparcels.csv");

            }

            this.CsvPrintparcels(retrieved);

        }

        public void CsvPrintcouriers(List<Courier> courierList)
        { // accepts full list of couriers, and then formats to a big string, then prints it to csv file
            int idinquestion;
            int idtocompare; //variables for loops to remove duplicates
            int firstIndex;
            int secondIndex;
            //as this method is sometimes called after a new version of a courier, with added or removed parcel, is added to end
            // it needs to account for removing the first version, to prevent duplicates
            for (firstIndex = 0; firstIndex < courierList.Count(); firstIndex++)
            { //for each courier, check the id of it courier, save it to a variable
                idinquestion = courierList[firstIndex].UniqueId;

                for (secondIndex = 0; secondIndex < courierList.Count(); secondIndex++)

                { //check it against a second loop on the same list
                    idtocompare = courierList[secondIndex].UniqueId;
                    if (idinquestion == idtocompare && firstIndex != secondIndex)
                    { // as long as they're not the same place in the list (ie. the exact same item)
                        courierList.RemoveAt(firstIndex); //take the earleier one out the list leaving the adapted one
                    }
                }

            }
            var csv = new StringBuilder();

            var line = ("");

            foreach (Courier cou in courierList)
            // looks and print each courier on the list
            {
                if (cou.GetType().ToString() == "BusinessObjects.Courier")
                {
                    continue; // a parent object can be returned when trying to assign 
                              //a parcel and none are available, this ensures it is not added to the sysytem by accident
                }
                // these next two chunks deal with printing the area and the parcel in a 
                //friendly manner for parsing later when getting read in 
                StringBuilder sixth = new StringBuilder();
                if (cou.Carrying.Count > 0)
                { // if the courier being looped over has 1 or + parcel to deliver
                    foreach (int carried in cou.Carrying)
                    { //  for each of the id's in the couriers list
                        sixth.Append(carried.ToString()); // add it to a string, divided by a 
                        sixth.Append('/'); // "/"
                    }
                }
                else
                {

                    sixth.Append(""); // else, keep the string blank

                }
                string six = sixth.ToString();
                StringBuilder seventh = new StringBuilder();
                if (cou.AssignedAreas.Count > 0) // this is the exact same as above, but with the areaCodes in each
                {
                    foreach (int area in cou.AssignedAreas)
                    {
                        seventh.Append(area.ToString());
                        seventh.Append('/');
                    }
                }
                else
                {
                    seventh.Append("");
                }

                string seven = seventh.ToString();
                //arrange the courier so it can be parsed
                line = string.Format("{0},{1}, {2}, {3}, {4}, {5}, {6}, {7}\n", cou.GetType().ToString(), cou.Name, cou.UniqueId, cou.MaxArea, cou.ParcelLimit, cou.HowManyAreas, six, seven);
                sixth.Clear(); // so appending isn't a problem next iteration
                six = ""; // so manipulating isn't a problem next iteration
                seventh.Clear(); // so appending isn't a problem 
                seven = ""; // so manipulating isn't a problem next iteration

                csv.Append(line); // add this line onto the big line

            }

            File.WriteAllText("courier3.csv", csv.ToString()); // print the big line to the csv

            csv.Clear(); // so using isn't a problem next iteration

        }

        public void CsvPrintparcels(List<Parcel> parcels)
        { // this method accepts a list of parcels, formats them into one big string of parcels, and then prints to csv

            StringBuilder wholedFile = new StringBuilder();

            foreach (Parcel p in parcels) // each parcel in the list passed in 
            {

                var extra = p.UniqueId;
                var first = p.Address;
                var second = p.PostCode;
                var third = p.AreaCode;

                wholedFile.Append(string.Format("{0},{1},{2},{3}\n", extra, first, second, third));

                //format, and add into big stringbuilder

            }
            File.WriteAllText("justparcels.csv", wholedFile.ToString()); // add it all onto specified file 
            wholedFile.Clear(); // clear the stringbuilder for next iteration

        }
        public List<Parcel> ReadParcelCsv()
        { // this method access the file of saved parcels, then reads it in, parsing each line into a parcel object, and adding it to a list of them
            string[] lines; //blank array of strings
                            // string currentLine;
            List<Parcel> parcelList = new List<Parcel>(); //empty list of parcels

            if (File.Exists("justparcels.csv")) //if a parcel is in the system(causing the file to exist)
            {
                lines = File.ReadAllLines("justparcels.csv"); // read all lines

                foreach (string line in lines)
                {
                    string[] parcelAttributes = line.Split(','); //divide by commas (as is a csv)

                    Parcel p = new Parcel(Convert.ToInt32(parcelAttributes[0]), parcelAttributes[1], parcelAttributes[2], Convert.ToInt32(parcelAttributes[3]));
                    parcelList.Add(p); // parse up and add to the list

                }

            }

            return parcelList;

        }

        public List<Courier> ReadCourierCsv()
        { // the exact same as the method above, but for couriers
            string[] lines;
            List<Courier> courierList = new List<Courier>();
            if (File.Exists("courier3.csv"))
            {
                lines = File.ReadAllLines("courier3.csv");

                string[] areables;
                string num;
                string area;

                foreach (string line in lines)
                {
                    string[] courierAttributesColumns = line.Split(',');

                    List<int> parcelids = new List<int>();
                    List<int> areas = new List<int>();

                    string typeCourier = courierAttributesColumns[0];
                    if (typeCourier == "BusinessObjects.Courier")
                    {

                        continue;
                    }
                    else if (courierAttributesColumns[6].Contains('/'))
                    // now dividing the areas and the parcel ids, adding each to the list of carrying/areasassigned for the courier currently being created

                    {
                        try
                        {
                            string[] nums = courierAttributesColumns[6].Split('/'); // divide by /

                            foreach (string nu in nums)
                            {
                                if (nu.Contains('/')) // searches for a "/" in the column with parcel ids 
                                {

                                    int whereslash = nu.IndexOf('/'); // if there is one
                                    num = nu.Remove(whereslash, 1); // take it out
                                }
                                else
                                {
                                    num = nu;
                                }
                                try // validation that only ints are left
                                {
                                    Convert.ToInt32(num);
                                    if (Convert.ToInt32(num) > 0)
                                    {
                                        try
                                        {
                                            parcelids.Add(Convert.ToInt32(num)); //if so, add it to the couriers in qustion's list of carrying
                                        }
                                        catch
                                        {

                                        }
                                    }
                                }
                                catch
                                {
                                    continue; // if there's something other than ints, there is a problem, and skip this iteration
                                }
                            }
                        }
                        catch { }
                    }

                    if (courierAttributesColumns[7].Contains('/'))
                    { // the exact same but for areaCodes instead of parcel ids

                        areables = courierAttributesColumns[7].Split('/');

                        foreach (string areable in areables)
                        {
                            if (areable.Contains('/'))
                            {
                                int whereslash = areable.IndexOf('/');
                                area = areable.Remove(whereslash, 1);
                            }
                            else
                            {
                                area = areable;
                            }
                            try
                            {
                                Convert.ToInt32(area);
                                if (Convert.ToInt32(area) > 0)
                                {
                                    try
                                    {
                                        //  int ar = Convert.ToInt32(areable);
                                        areas.Add(Convert.ToInt32(area));

                                    }
                                    catch
                                    {
                                        // areas.Add(0);
                                    }
                                }
                            }
                            catch { }

                        }
                    }
                    if (typeCourier == "BusinessObjects.CycleCourier")
                    {
                        CycleCourier cc = new CycleCourier(courierAttributesColumns[1], Convert.ToInt32(courierAttributesColumns[2]), Convert.ToInt32(courierAttributesColumns[3]), Convert.ToInt32(courierAttributesColumns[4]), Convert.ToInt32(courierAttributesColumns[5]), parcelids, areas);
                        courierList.Add(cc); // make a new cycle courier object using the type, adding the parsed values
                    }
                    else if (typeCourier == "BusinessObjects.VanCourier")
                    {
                        VanCourier vc = new VanCourier(courierAttributesColumns[1], Convert.ToInt32(courierAttributesColumns[2]), Convert.ToInt32(courierAttributesColumns[3]), Convert.ToInt32(courierAttributesColumns[4]), Convert.ToInt32(courierAttributesColumns[5]), parcelids, areas);
                        courierList.Add(vc); // make a new van courier object using the type, adding the parsed values
                    }
                    else if (typeCourier == "BusinessObjects.WalkingCourier")
                    {
                        WalkingCourier wc = new WalkingCourier(courierAttributesColumns[1], Convert.ToInt32(courierAttributesColumns[2]), Convert.ToInt32(courierAttributesColumns[3]), Convert.ToInt32(courierAttributesColumns[4]), Convert.ToInt32(courierAttributesColumns[5]), parcelids, areas);
                        courierList.Add(wc); // make a new walking courier object using the type, adding the parsed values
                    }
                }

            }

            int idinquestion;
            int idtocompare;
            int firstIndex;
            int secondIndex;
            for (firstIndex = 0; firstIndex < courierList.Count(); firstIndex++)
            { // this loop works to remove and prevent duplicates, by checking one courier id in the list, finding matches, and removing it if it's not at the 
              // same index (ie. it's not comparing against itself), a
                idinquestion = courierList[firstIndex].UniqueId;

                for (secondIndex = 0; secondIndex < courierList.Count(); secondIndex++)

                {
                    idtocompare = courierList[secondIndex].UniqueId;
                    if (idinquestion == idtocompare && firstIndex != secondIndex)
                    {
                        courierList.RemoveAt(firstIndex);
                    }
                }

            }

            return courierList; // return list with no-duplicates

        }

    }
}