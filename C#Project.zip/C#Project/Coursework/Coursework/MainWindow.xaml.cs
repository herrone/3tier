﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.VisualBasic;
using BusinessObjects;

/* Delivery System Coursework 
 * Author - Emily Herron
 * Matric - 40506487
 * Completed on 22/11/21
 */

namespace Presentation
{
    /// <summary>
    /// Interaction Logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }

        private Courier myCourier = new Courier();

        private Parcel par = new Parcel();

        private void BtnSave_Courier_Click(object sender, RoutedEventArgs e)
        { //this method eventually saves the courier into the db
            try
            {
                if (((txtCourierType.Text == "Van" || txtCourierType.Text == "van") && txtCourierName.Text.Length > 0)) //if it is a van courier
                                                                                    //these if/else statement are the same, just the type of courier changes, so I have only commented once
                {
                    VanCourier myVanCourier = new VanCourier(txtCourierName.Text); // the name is from the name box

                    displayBox.Text = "Van courier added"; // Print a positive message
                    myVanCourier.LogIt("addcourier"); //Log event
                    myVanCourier.AddMe(); // add courier to db via facade

                }
                else if ((txtCourierType.Text == "Cycle" || txtCourierType.Text == "cycle") && txtCourierName.Text.Length > 0) //repeat of above but Cycle instead of van
                {
                    CycleCourier myCycleCourier = new CycleCourier(txtCourierName.Text);

                    myCycleCourier.AddMe();
                    myCycleCourier.LogIt("addcourier");
                    displayBox.Text = "Cycle courier added";

                }
                else if ((txtCourierType.Text == "Walking" || txtCourierType.Text == "walking") && txtCourierName.Text.Length > 0) //repeat of above but Walking instead of van
                {
                    WalkingCourier myWalkingCourier = new WalkingCourier(txtCourierName.Text);

                    displayBox.Text = "Walking Courier added";
                    myWalkingCourier.AddMe();
                    myWalkingCourier.LogIt("addcourier");

                }
                else
                {
                    txtCourierType.Text = "That is not a valid courier type";
                }

            }
            catch 
            {
                txtCourierType.Text = "This isn't working";
            }

        }

        private void Btnget_Delivery_List_Click(object sender, RoutedEventArgs e)
        // this method displays a formatted delivery list for a courier's id.
        {
            try
            {
                String dlist = myCourier.GetDeliveryList(Convert.ToInt32(courierIDDeliveryTextBox.Text)).ToString();
                // calls the courier method to get the delivey list, using whatever was put in the corresponding textbox as a parameter

                if (dlist.Length == 0) // if the list is empty
                {
                    dlist = "There are no deliveries scheduled for this courier\n";

                }

                displayBox.Text = dlist; // display
            }
            catch {
                courierIDDeliveryTextBox.Text = "That isn't a valid courier ID";
            }
        }
        private void BtnAddParcel_Click(object sender, RoutedEventArgs e)
        {
            int areaCode;
          //= 0;
            // this method uses the two corresponding textboxes to create a new parcel object

             char[] postcodeletters = txtParcelPostCode.Text.ToCharArray(); // to get area code, we turn postcode into char array

                if (postcodeletters[3] == ' ') // if there is two numbers (EH12)
                {
                string area = postcodeletters[2].ToString();
                //string area = postcodeletters[2].ToString() + postcodeletters[3].ToString();
                areaCode = Convert.ToInt32(area); //convert it to area code

                }
                else 
                {
                    string acstring = postcodeletters[2].ToString(); //else areacode is one number (EH7)
                    areaCode = Convert.ToInt32(acstring);
                  //  areaCode = 7;
                    //set the areaCode
                }
                if (areaCode > 22)
                {
                    displayBox.Text = "This parcel is out of range";
                }

                else
                {
                    Parcel myParcel = new Parcel(txtParcelAddress.Text, txtParcelPostCode.Text);


                    myParcel.AddMe(); // this adds the parcel to the document

                    displayBox.Text = "Parcel " + myParcel.UniqueId + " added"; // displays a user-friendly message to let them know it's been done 

                    if (myParcel.FindCourier().GetType().ToString() == "BusinessObjects.Courier") //if the parent object is returned, it means a child object was unavailable, but the parcel will still  be in the system
                    {
                        displayBox.Text = "There are no available couriers";

                    }
                    else
                    {
                        myParcel.FindCourier().AddMe(); //add the courier, now with the parcel in his list, to the system ( the db layer will remove older object/duplicates)

                    }

                }
           
        }

        

        private void Show_all_couriers_click(object sender, RoutedEventArgs e)
        {
            try
            {
                List<Courier> couriers = myCourier.GetAllCouriers(); // obtains all couriers in system

                if (couriers.Count > 0) // if there are couriers
                {
                    string retrieved = couriers[0].PrintListOfCouriers(couriers); // send list to be formatted            
                    displayBox.Text = retrieved; // print formatted list
                }
            }
            catch //if there are none
            {
                displayBox.Text = "There aren't any couriers yet"; // say as much
            }

        }

        private void Transfer_Button_Click(object sender, RoutedEventArgs e)
        { // this method moves the parcel id and assigned area from one courier, to another

            List<Courier> cous = myCourier.GetAllCouriers(); //obtain list of all couriers in system
            if (cous.Count < 2)
            {
                displayBox.Text = "There are no couriers available to assign this to";
            }
            else
            {
                try
                {
                    int pid = Convert.ToInt32(transferIDText.Text); // get the id of the parcel which should be transferred
                    cous[0].RemoveParcel(pid); // this method searches a list of couriers to find the one with the parcel, and removes the parcel it from the courier

                    List<Parcel> allP = par.GetAllParcels(); //obtain full list of parcels

                    par.PrintParcels(allP); //print them back onto document

                    foreach (Parcel p in allP) //searches parcel id against full list
                    {
                        if (p.UniqueId == pid) //  when it's found
                        {
                            p.FindCourier().AddMe(); // find a new courier and add it to list of couriers, to print

                        }
                    }

                    displayBox.Text = "Parcel transferred to new Courier!"; //display positive message

                }

                catch
                {
                    transferIDText.Text = "This parcel ID is not valid";
                }
            
            }

        }

    }
}