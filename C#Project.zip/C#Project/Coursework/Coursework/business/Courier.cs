﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer;

/* Delivery System Coursework 
 * Author - Emily Herron
 * Matric - 40506487
 * Completed on 22/11/21
 */

namespace BusinessObjects
{
    public class Courier

    // Represents a Courier, with a list of parcel id numbers

    {
        private String _name;
        private int _uniqueId;
        private int _maxArea; // for different courier objects there are different permissons, e.g Vans can go anywhere, walkers can only do areas 1-4.
        private int _parcelLimit;
        private int _howManyAreas;
        private List<int> _assignedAreas; //each parcel's area code is parsed from it's postcode and added here, provided it is within the 
        private List<int> _carrying = new List<int>(); // List of assigned parcel ids
        DataFacadeSingleton df = DataFacadeSingleton.GetInstance();
        public Courier()
        {
            // empty constructor for instantiating objects for manipulation
            Random random = new Random();
            _uniqueId = random.Next();
            _maxArea = 0;
            _parcelLimit = 0;
            _howManyAreas = 0;

            _assignedAreas = new List<int>();

        }
        public Courier(string name)
        { // basic constructor for instantiating objects, taking only name
            _name = name;

            Random random = new Random();
            _uniqueId = random.Next();
            _maxArea = 0;
            _parcelLimit = 0;
            _howManyAreas = 0;
            _assignedAreas = new List<int>();

            /* as my system doesn't require any plain 'courier' objects, all of the attributes are sent to 0 to
                   * disallow any parcels to be added to it if one falls through the cracks into a list
                   */

        }
        
        public Courier(string name, int id, int maxarea, int parcellimit, int howmanyareas, List<int> assigned)
        {
            // for use when reading back in from the csv file
            _name = name;
            _uniqueId = id;
            _maxArea = maxarea;
            _parcelLimit = parcellimit;
            _howManyAreas = howmanyareas;
            _assignedAreas = assigned;

        }
        public void LogIt(string code)
        { // calls db facade to print to logfile 

            df.LogItdf(code);
        }
        public void AddMe()
        { // calls db facade to have courier added to the files

            df.AddCourierdf(this);
            //df.LogItdf("addcourier");
        }
        public List<Courier> GetAllCouriers()
        { // calls databasefacade method, obtaining full list of couriers

            return df.GetAllCouriersdf();

        }
        public Courier(string name, int id, int maxarea, int parcellimit, int howmanyareas, List<int> carrying, List<int> assigned)
        {
            // for use when reading back in from the csv file when couriers already have (an) assigned parcel(s)
            _name = name;
            _uniqueId = id;
            _carrying = carrying;
            _maxArea = maxarea;
            _parcelLimit = parcellimit;
            _howManyAreas = howmanyareas;
            _assignedAreas = assigned;

        }
        public Courier AssignToThem(Parcel a)
        {
            //method which takes in a parcel, adds it to courier (2 stages), and returns courier
            _carrying.Add(a.UniqueId); // adds the id to the list of carried "parcels"
            _assignedAreas.Add(a.AreaCode); // adds the parcel area code (ie. EH2 = 2) to the couriers assigned area codes

            return this; // return the courier

        }
        public string PrintListOfCouriers(List<Courier> courieers)
        { // PrintListOfCouriers returns a formatted string representation of all of the couriers in the system from a list of couriers, and a list of parcels (linked via unique id)

            StringBuilder builder = new StringBuilder();
            StringBuilder emptyCourier = new StringBuilder();
            df.LogItdf("getall");

            foreach (Courier cou in courieers) // for each of the couriers in the list
            {
                List<int> areas = new List<int>();
                string type = cou.GetType().ToString(); // Get a string version of the type, to differentiate between the three
                string mytype = "";
                if (type == "BusinessObjects.VanCourier")
                {
                    mytype = "Van"; // a new variable for more succinct Printing
                }
                else if (type == "BusinessObjects.WalkingCourier")
                {
                    mytype = "Walking";
                }
                else if (type == "BusinessObjects.CycleCourier")
                {
                    mytype = "Cycle";
                }

                List<int> lister = cou.Carrying; // save into a new list
                int carryLength = lister.Count;
                if (cou._assignedAreas.Count > 0) // if they have any assigned parcels or zones
                {
                    foreach (int are in cou._assignedAreas)
                    { // for each of them make a string explaining the area, and courier details, appended toGether
                        if(areas.Count > 0)
                        {
                            if (areas.Contains(are))
                            {
                                continue;
                            }
                            else
                            {
                                areas.Add(are);
                              

                            }
                        }
                        string line = ("EH" + are + " - Courier " + cou.UniqueId + ", Type : " + mytype + ", Capacity; " + carryLength + "/" + cou.ParcelLimit + "\n");
                        if (!builder.ToString().Contains(line))
                        {
                            builder.Append(line);
                        }
                       
                    }

                }
                else // if they have no assigned areas or parcels
                {
                    emptyCourier.Append("Courier " + cou.UniqueId + ", Type : " + mytype + " is currently unassigned to an area and carrying no parcels, please add a parcel to remedy. \n");
                    // make a nice string explaining as such, and append each similar line to it
                }
            }

            builder.Append(emptyCourier); // add the two long strings toGether
            return builder.ToString(); // return
        }
        public StringBuilder GetDeliveryList(int id)
        {
            // this method returns a stringbuilder representation of a delivery list, taken from a specified id
            DataFacadeSingleton df = DataFacadeSingleton.GetInstance();
            List<Courier> fetchC = df.GetAllCouriersdf(); // Get a list of all couriers in system
            List<Parcel> getP = df.GetAllParcelsdf(); // Get a list of all parcels in system
            df.PrintParcelsdf(getP); // as GetAllParcels deletes the file to prevent duplications, we Print it back out the same as no changes
            df.LogItdf("showdeliverylist"); // calls df logfile, passing a code
            StringBuilder bigLine = new StringBuilder();
            int parcelCounter = 1;

            foreach (Courier cou in fetchC) // for each courier in system ( we are trying to find the courier with the id matching the parameter)
            {

                if (cou.UniqueId == id && cou.Carrying.Count > 0) // if it is this one, and there's any deliverys to be made
                {
                    bigLine.Append("Courier " + id + " delivery list : \n"); // to introduce the courier

                    foreach (int num in cou.Carrying) // for each parcel id on the list
                    {

                        foreach (Parcel p in getP) // for each parcel in system (we are trying to find the parcel with the id matching up)
                        {

                            if (num == p.UniqueId) // if id on list is the same as this parcel 
                            {

                                bigLine.Append("Parcel " + parcelCounter + ", Address : " + p.Address + "," + ", Postcode " + p.PostCode + "\n");
                                // add parcel details to the string representation
                                parcelCounter++;

                            }
                        }

                    }
                }
            }

            return bigLine; // return representation
        }
        public void RemoveParcel(int pid)

        { //RemoveParcel returns nothing, but it takes in a parcel id, then searches to find the courier who has it in their list, and removes it (part of transfer)
            DataFacadeSingleton df = DataFacadeSingleton.GetInstance();
            List<Courier> fetchC = df.GetAllCouriersdf();

            df.LogItdf("transferparcel");
            int remArea;

            List<Parcel> getP = df.GetAllParcelsdf(); // same as prior methods
            df.PrintParcelsdf(getP);

            foreach (Courier cou in fetchC.ToList()) // for each courier (toList is used incase it has been changed during runtime)
            {
                foreach (int carry in cou.Carrying.ToList()) // take each of their parcel ids
                {
                    if (carry == pid) // if it is the correct courier, this will be true , as the parcel id we want to compare will be in their list of parcel ids
                    {
                        cou.Carrying.Remove(pid); // remove it from list
                        foreach (Parcel p in getP) // for each parcel in system
                        {
                            if (pid == p.UniqueId) // if the id in question is the same as the parcel id
                            {
                                remArea = p.AreaCode; // take the area code
                                cou.AssignedAreas.Remove(remArea); // remove it from couriers list as well

                                df.AddCourierdf(cou); // add the courier back to the document with amendments (the addCourier method will take care of duplicates)

                            }

                        }
                    }

                }
            }

        }

        // Getters and setters are below
        public int HowManyAreas
        {
            get
            {
                return _howManyAreas;
            }

            set
            {
                _howManyAreas = value;
            }
        }

        public int UniqueId
        {
            get
            {
                return _uniqueId;
            }

            set
            {
                _uniqueId = value;
            }
        }

        public int MaxArea
        {

            get
            {
                return _maxArea;
            }
            set
            {
                _maxArea = value;
            }

        }
        public int ParcelLimit
        {

            get
            {
                return _parcelLimit;
            }
            set
            {
                _parcelLimit = value;
            }

        }
        public List<int> Carrying
        {

            get
            {
                return _carrying;
            }
            set
            {
                _carrying = value;
            }
        }

        public List<int> AssignedAreas
        {
            get
            {
                return _assignedAreas;
            }
            set
            {
                _assignedAreas = value; ;
            }

        }
        public String Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }

        }

    }
}