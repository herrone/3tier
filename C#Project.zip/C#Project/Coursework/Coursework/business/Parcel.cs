﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer;

/* Delivery System Coursework 
 * Author - Emily Herron
 * Matric - 40506487
 * Completed on 22/11/21
 */

namespace BusinessObjects
{
    public class Parcel
    {
        // Represents a parcel with attributes:

        int _uniqueId;
        string _address;
        string _postcode;
        int _areaCode;
        DataFacadeSingleton df = DataFacadeSingleton.GetInstance();

        public Parcel()
        {

        }

        public Parcel(string add, string post)
        {  // constructor with 2 parameters
            Random random = new Random();
            this._uniqueId = random.Next(); // assign random id
            this._address = add;
            this._postcode = post;
          
            char[] postcodeletters = post.ToCharArray(); // to get area code, we turn postcode into char array

            if (postcodeletters[3] != ' ') // if there is two numbers (EH12)
            {
                string area = postcodeletters[2].ToString() + postcodeletters[3].ToString();
                this.AreaCode = Convert.ToInt32(area);
                //convert it to area code


            }
            else
            {
                string acstring = postcodeletters[2].ToString(); //else areacode is one number (EH7)
                this.AreaCode = Convert.ToInt32(acstring);
                //set the areaCode
            }


        }
        public Parcel(int id, string add, string post, int areaCode)
        {
            _uniqueId = id;
            _address = add;
            _postcode = post;
            _areaCode = areaCode;
        } //for reading back in with full attributes

        public void AddMe() 
        {
            df.AddParceldf(this); // calls df to add parcel to files
            df.LogItdf("addparcel"); // same for message to logfile
        }
     
        public List<Parcel> GetAllParcels()
        { //calls df and returns a list of all parcels in system
           return df.GetAllParcelsdf();
        }
        public void PrintParcels(List<Parcel> ps)
        { // sends a full list of parcels to be printed to files via databasefacade
            df.PrintParcelsdf(ps);
        }
        public Courier FindCourier()
        { //FindCourier finds a courier to take this parcel
           
            List<Courier> courieres = df.GetAllCouriersdf(); // to do this we need to take the full list
            foreach (Courier cou in courieres) //cycle through them
            {
          
                Boolean same = false; // this will see if, for couriers who can't be in more than one area, they can take this parcel
                if (cou.AssignedAreas.Count > 0) 
                {
                    foreach (int assigned in cou.AssignedAreas) //Get all the courier's areas
                    {
                        if (assigned == this.AreaCode) // if the area is the same as the parcel you are trying to dispense out
                        {
                            same = true; //make it true

                        }

                    }
                }
                if (cou.MaxArea >= this._areaCode && cou.Carrying.Count < cou.ParcelLimit && (cou.AssignedAreas.Count < cou.HowManyAreas || same == true))
                { // if the courier has availability, and isn't over it's area limit, and is allowed to be in this area (or the area is the same one if not van)

                  

                    cou.AssignToThem(this);
                    //this updates the found courier and adds this parcel ID to the list
                    return cou; //return it

                }




            }
            Courier courier = new Courier(); // this will be deleted later when trying to Print/read it 
            return courier; // if this is returned it will be ignored
        }
        //getters and setters
        public string Address
        {

            get
            {
                return _address;
            }
            set
            {
                _address = value;
            }

        }
        public int UniqueId
        {

            get
            {
                return _uniqueId;
            }
            set
            {
                _uniqueId = value;

            }

        }
        public string PostCode
        {

            get
            {
                return _postcode;
            }
            set
            {
                _postcode = value;

            }

        }
        public int AreaCode
        {

            get
            {
                return _areaCode;
            }
            set
            {
                _areaCode = value;

            }

        }
    }
}