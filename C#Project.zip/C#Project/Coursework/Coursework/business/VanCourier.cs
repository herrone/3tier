﻿using System;
using System.Collections.Generic;

/* Delivery System Coursework 
 * Author - Emily Herron
 * Matric - 40506487
 * Completed on 22/11/21
 */

namespace BusinessObjects
{
    public class VanCourier : Courier
    {
        // Represents a VanCourier, inherited from Courier, with a list of parcel id numbers
        public VanCourier()
        {

        }
        public VanCourier(string name) : base(name)
        {  // constructor passes to parent
            this.MaxArea = 22;
            this.ParcelLimit = 100;
            this.HowManyAreas = 22;
            //sets variables as per spec

        }
        public VanCourier(string name, int id, int maxarea, int parcellimit, int howmanyareas, List<int> assigned) : base(name, id, maxarea, parcellimit, howmanyareas, assigned)
        {  // constructor passes to parent
            this.Name = name;
            this.UniqueId = id;
            this.MaxArea = maxarea;
            this.ParcelLimit = parcellimit;
            this.HowManyAreas = howmanyareas;
            this.AssignedAreas = assigned;
          
        }

        public VanCourier(string name, int id, int maxarea, int parcellimit, int howmanyareas, List<int> carrying, List<int> assigned) : base(name, id, maxarea, parcellimit, howmanyareas, carrying, assigned)
        {  // constructor passes to parent
            this.Name = name;
            this.UniqueId = id;
            this.MaxArea = maxarea;
            this.ParcelLimit = parcellimit;
            this.HowManyAreas = howmanyareas;
            this.AssignedAreas = assigned;
            this.Carrying = carrying;

        }

    }
}