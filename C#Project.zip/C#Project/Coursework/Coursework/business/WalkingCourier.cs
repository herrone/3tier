﻿using System;
using System.Collections.Generic;

/* Delivery System Coursework 
 * Author - Emily Herron
 * Matric - 40506487
 * Completed on 22/11/21
 */

namespace BusinessObjects
{
    class WalkingCourier : Courier
    {
        // Represents a WalkingCourier, inherited from Courier, with a list of parcel id numbers
        public WalkingCourier() { }

        public WalkingCourier(string name) : base(name)
        { // constructor passes to parent
            this.MaxArea = 4;
            this.HowManyAreas = 1;
            this.ParcelLimit = 5;

        }
        public WalkingCourier(string name, int id, int maxarea, int parcellimit, int howmanyareas, List<int> assigned) : base(name, id, maxarea, parcellimit, howmanyareas, assigned)
        { // constructor passes to parent
            this.Name = name;
            this.UniqueId = id;
            this.MaxArea = maxarea;
            this.ParcelLimit = parcellimit;
            this.HowManyAreas = howmanyareas;
            this.AssignedAreas = assigned;

        }

        public WalkingCourier(string name, int id, int maxarea, int parcellimit, int howmanyareas, List<int> carrying, List<int> assigned) : base(name, id, maxarea, parcellimit, howmanyareas, carrying, assigned)
        {  // constructor passes to parent
            this.Name = name;

            this.UniqueId = id;
            this.Carrying = carrying;
            this.MaxArea = maxarea;
            this.ParcelLimit = parcellimit;
            this.HowManyAreas = howmanyareas;
            this.AssignedAreas = assigned;

        }

    }
}