﻿using System;
using System.Collections.Generic;

/* Delivery System Coursework 
 * Author - Emily Herron
 * Matric - 40506487
 * Completed on 22/11/21
 */

namespace BusinessObjects
{
    class CycleCourier : Courier
    {
        // Represents a CycleCourier, inherited from Courier, with a list of parcel id numbers
        public CycleCourier() { }
        public CycleCourier(string name) : base(name)
        { // constructor passes to parent
            this.MaxArea = 22;
            this.HowManyAreas = 1;
            this.ParcelLimit = 10;

        }
        public CycleCourier(string name, int id, int maxarea, int parcellimit, int howmanyareas, List<int> assigned) : base(name, id, maxarea, parcellimit, howmanyareas, assigned)
        { // constructor passes to parent
            this.Name = name;
            this.UniqueId = id;
            this.MaxArea = maxarea;
            this.ParcelLimit = parcellimit;
            this.HowManyAreas = howmanyareas;
            this.AssignedAreas = assigned;

        }
        public CycleCourier(string name, int id, int maxarea, int parcellimit, int howmanyareas, List<int> carrying, List<int> assigned) : base(name, id, maxarea, parcellimit, howmanyareas, carrying, assigned)
        { // constructor passes to parent
            this.Name = name;

            this.UniqueId = id;
            this.MaxArea = maxarea;
            this.ParcelLimit = parcellimit;
            this.HowManyAreas = howmanyareas;
            this.AssignedAreas = assigned;
            this.Carrying = carrying;

        }
    }
}