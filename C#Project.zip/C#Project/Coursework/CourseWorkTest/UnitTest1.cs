﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BusinessObjects;
//using BusinessObjects;
using Coursework;
using DataLayer;
using Presentation;
using System;

namespace CourseWorkTest
{
    [TestClass]
    public class UnitTest1
    {
        private TestContext testContextInstance
        {
            get { return testContextInstance; }
            set { testContextInstance = value; }
        }
        // private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>

        [TestMethod]
        public void testAreaCode()
        {
            Parcel target = new Parcel("24 Zoo lane", "EH20 3gh");
            target.AddMe();
            Assert.AreSame(target.AreaCode, 20);

        }

        [TestMethod]
        public void testAddingToList() 
        {
            Parcel target2 = new Parcel("23 Zoo lane", "EH21 3gh"); // TODO: Initialize to an appropriate value
            DataFacadeSingleton df = DataFacadeSingleton.GetInstance();
            int lengthbefore = df.GetAllParcelsdf().Count;
            target2.AddMe();
            int lengthnow = df.GetAllParcelsdf().Count;
            Assert.AreSame(lengthnow, (lengthbefore + 1));

        }
        /// <summary>
        ///A test for seeing if a courier gets assigned or not
        ///</summary>
        [TestMethod]
        public void testFindCourier()
        {
            Parcel target3 = new Parcel("22 Zoo lane", "EH19 3gh"); // TODO: Initialize to an appropriate value
            DataFacadeSingleton df = DataFacadeSingleton.GetInstance();
            VanCourier testCourier = new VanCourier("Bart");
            testCourier.AddMe();
            string testNameReturn = target3.FindCourier().Name;
            Assert.AreSame(testNameReturn, "Bart");

        }
    }
}
